const path = require("path");

const express = require("express");
const dotEnv = require("dotenv");

const isAuth = require('./middlewares/is-auth');
const {multer, fileFilter, fileStorage} = require('./config/fileHandle');
const cors = require('./config/setHeader');
const sequelize = require("./config/database");
const relation = require("./models/relations/relations");

const app = express();
//tables relations
relation();
// Load Config
dotEnv.config({path: "./config/config.env"});
//BodyParser
app.use(express.json());
// file(image) handler
// app.use(multer({ storage: fileStorage, fileFilter: fileFilter}).single('image'));


app.use(multer({storage: fileStorage, fileFilter: fileFilter}).single('image'));
// global image directory
app.use('/images', express.static(path.join(__dirname, 'storage', 'images')));
// Cross-Origin Resource Sharing for handle headers
app.use(cors);
//authentication middleware
app.use("/api/user", require("./routes/user"));
app.use(isAuth);
// Routes
app.use("/api/business", require("./routes/business"));
app.use("/api/person", require("./routes/person"));
app.use("/api/personType", require("./routes/personType"));
app.use("/api/seller", require("./routes/seller"));
app.use("/api/project", require("./routes/project"));
app.use("/api/product", require("./routes/product"));
app.use("/api/category", require("./routes/category"));
app.use("/api/accounting", require("./routes/accounting"));
app.use("/api/transfer", require("./routes/transfer"));
app.use("/api/sale", require("./routes/sale"));
app.use("/api/saleReturn", require("./routes/saleReturn"));
app.use("/api/buy", require("./routes/buy"));
app.use("/api/buyReturn", require("./routes/buyReturn"));
app.use("/api/income", require("./routes/income"));
app.use("/api/receive", require("./routes/receive"));
app.use("/api/cost", require("./routes/cost"));
app.use("/api/payment", require("./routes/payment"));
app.use("/api/bank", require("./routes/bank"));
app.use("/api/fund", require("./routes/fund"));
app.use("/api/cashier", require("./routes/cashier"));
app.use("/api/cheque", require("./routes/cheque"));
app.use("/api/warehouse", require("./routes/warehouse"));
app.use("/api/warehouseHandle", require("./routes/warehouseHandle"));
app.use("/api/waste", require("./routes/waste"));

// handle errors
app.use(require('./controllers/errorHandele/errorController').getErrors);
app.use(require('./controllers/errorHandele/errorController').get404);
const PORT = process.env.PORT || 8080;
sequelize
    .sync({force:true})
    .then((result) => {
        console.log(result);
        app.listen(PORT, () => {
            console.log(`server is running in port:${PORT} on ${process.env.NODE_ENV}`)
        });
    })
    .catch((err) => console.log(err));
