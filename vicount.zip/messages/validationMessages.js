export default {
  user_first_name_required: "نام را وارد نمایید",
  user_first_name_max: "نام نامعتبر",
  user_last_name_required: "نام را وارد نمایید",
  user_last_name_max: "نام نامعتبر",
};
