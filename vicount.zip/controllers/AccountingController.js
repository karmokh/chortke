const Accounting = require("../models/Accounting");
exports.index = async (req,res,next)=>{}
exports.show = async (req,res,next)=>{}
exports.create = async (req,res,next)=>{}
exports.update = async (req,res,next)=>{}
exports.delete = async (req,res,next)=>{}