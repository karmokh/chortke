const PersonType = require("../models/Person_Type");
exports.index = async (req,res,next)=>{}
exports.show = async (req,res,next)=>{}
exports.create = async (req,res,next)=>{}
exports.update = async (req,res,next)=>{}
exports.delete = async (req,res,next)=>{}